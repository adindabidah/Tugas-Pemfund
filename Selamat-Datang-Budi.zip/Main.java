class Main {
  public static void main(String[] args) {
    String nama = "Muhammad Affandes";
    System.out.println("Hai " + nama );
    System.out.println("Selamat datang di MyApp.");
    System.out.println("========================");
    System.out.println("Terimakasih " + nama + " sudah membeli aplikasi ini.");
    System.out.println("Support: support@myapp.co.id");
  }
}