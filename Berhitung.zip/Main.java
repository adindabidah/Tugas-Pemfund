import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int nilai = input.nextInt();
    
    for (int i = 1; i <= nilai; i++ ) {
    System.out.println( i );
  }
  }
}