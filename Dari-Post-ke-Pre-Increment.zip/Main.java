class Main {
  public static void main(String[] args) {
    int x = 11;
    int y = x;			
    System.out.println(x);
    System.out.println(y);
  }
}